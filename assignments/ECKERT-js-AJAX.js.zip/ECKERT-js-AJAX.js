// Expand our front-end for the art-share API.

// Create a form that allows your 'hard coded' user to create a painting.

// Create an additional form to allow users to sign up with their own first name, last name, password & email.

// Optionally, update the DOM with paintings that belong to your user, using listPaintings() from art-share.js as a starting point.